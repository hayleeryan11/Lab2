package edu.tacoma.uw.css.haylee11.spookybois;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class imageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image);
    }
}
